package com.example.myapplication1;
import com.example.myapplication1.FullscreenActivity;

public class NextActivity extends FullscreenActivity {

}